<!-- Page -->
<div class="page">
  <div class="page-header">
    <h1 class="page-title">Dashboard</h1>
  </div>
  <div class="page-content container-fluid">
    <div class="row">
      <div class="col-xl-3 col-md-4">
        <!-- Panel -->

        <!-- End Panel -->
      </div>
      <div class="col-xl-9 col-md-8">
        <!-- Panel -->
        
        <!-- End Panel -->
      </div>
    </div>
  </div>
</div>
<!-- End Page -->